
const fs = require("fs"); 

fs.readFile("abc.txt",(err, data) =>{

     if(err){
        console.log(err);
     }
     else{
         var content = data.toString();

         fs.writeFile("xyz.txt",content,(err) =>{
            if(err){
                console.log(err);
            }
         })
     }

})

