
const fs = require('fs');

const readStream = fs.createReadStream("100mb-examplefile-com.txt");

var data = "";

readStream.on("data", (chunk) => {  
    
     data = data + chunk;
     console.log("Received " + chunk.length + " bytes of data.");

})

readStream.on("end", () => {
    console.log("No more data.");
    console.log("Total data length: " + data.length);
});

readStream.on("error", (err) => {
    console.log("Error: " + err);
})