const http = require('http');
const fs = require('fs');
const path = require('path');

const server = http.createServer((req, res) => {
  const filePath = path.join(__dirname, 'a.avi');

  fs.stat(filePath, (err, stats) => {
    if (err) {clea
      console.error(err);
      return res.writeHead(404).end("Video not found");
    }

    const range = req.headers.range;

    if (!range) {
      // No range → send entire file (not ideal for big videos)
      res.writeHead(200, {
        'Content-Type': 'video/mp4',
        'Content-Length': stats.size
      });
      fs.createReadStream(filePath).pipe(res);
      return;
    }

    // Parse Range header: "bytes=start-end"
    const CHUNK_SIZE = 10 ** 6; // optional cap
    const [startStr, endStr] = range.replace(/bytes=/, "").split("-");
    const start = parseInt(startStr, 10);
    const end = endStr ? parseInt(endStr, 10) : Math.min(start + CHUNK_SIZE, stats.size - 1);

    const contentLength = end - start + 1;

    res.writeHead(206, {
      "Content-Range": `bytes ${start}-${end}/${stats.size}`,
      "Accept-Ranges": "bytes",
      "Content-Length": contentLength,
      "Content-Type": "video/mp4"
    });

    fs.createReadStream(filePath, { start, end }).pipe(res);
  });
});

server.listen(3000, () => {
  console.log("Server running on http://localhost:3000");
});
