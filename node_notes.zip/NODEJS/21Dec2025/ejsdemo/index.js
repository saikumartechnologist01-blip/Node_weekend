
var express = require('express');

var app = express();

var userRouter = require("./routes/user.route");

app.use(express.json());

app.use(express.urlencoded({extended:true}));

app.use('/user', userRouter);

app.set('view engine','ejs');

app.set('views', __dirname + '/views');

app.get('/', (req, res) => {
    res.render('index');
});

app.listen(3001, () =>{
    console.log('Server is running on port 3001');
})
