
var userRouter = require('express').Router();


userRouter.get("/login",(req,res) =>{
    res.render('login', {message: ''});
})

userRouter.get("/register",(req,res) =>{
    res.render('register', {message: ''});
})

userRouter.post("/login", (req,res) =>{

    var userInfo = req.body;
    console.log(userInfo);

     if(userInfo.email == "sai@gmail.com" && userInfo.password == "12345"){
         res.render('login',{message: "Login Successful"});
     }
     else{
        res.render('login',{message: "Invalid Credentials"});
     }
})

userRouter.post("/register", (req,res) =>{
    res.render('register',{message: "Registration Successful"});
})


module.exports = userRouter;