const fs = require('fs');
const ReadStream = fs.createReadStream("100mb.txt",{
    highWaterMark:16 * 1024 //16KB
});

ReadStream.on('data',(chunk) =>{
    console.log("--------------------------------------------------");
    console.log("Received "+ chunk.length + " bytes of data.");
    console.log(chunk.toString());
    console.log("--------------------------------------------------");
})

ReadStream.on('end',() =>{
    console.log("No more data to read. processing completed");
})

ReadStream.on('error',(err) =>{
    console.log("Error occurred while reading the file.");
    console.log(err.message);
});