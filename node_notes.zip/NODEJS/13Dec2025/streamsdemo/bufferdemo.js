const fs = require('fs');

const CHUNK_SIZE = 20 * 1024; // 20 KB
const stream = fs.createReadStream('100mb.txt', {
  highWaterMark: CHUNK_SIZE
});

let buffer = Buffer.alloc(0);

stream.on('data', (chunk) => {
  buffer = Buffer.concat([buffer, chunk]);

  while (buffer.length >= CHUNK_SIZE) {
    const fixedChunk = buffer.slice(0, CHUNK_SIZE);
    buffer = buffer.slice(CHUNK_SIZE);

    console.log('----------------------------------------');
    console.log('Received fixed chunk:', fixedChunk.length, 'bytes');
    //console.log(fixedChunk.toString());
    // process fixedChunk here
  }
});

stream.on('end', () => {
  // Handle leftover data (last chunk)
  if (buffer.length > 0) {
    console.log('----------------------------------------');
    console.log('Final chunk:', buffer.length, 'bytes');
    // process remaining buffer here
  }

  console.log('No more data to read. Processing completed.');
});

stream.on('error', (err) => {
  console.error('Error occurred while reading the file:', err.message);
});
