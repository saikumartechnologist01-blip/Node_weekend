
const http = require("http");

const server = http.createServer((request, response)=>{

    response.writeHead(200, {'Content-Type': 'text/plain'});
    response.end("Hello, World! This is my first web application using node! This is exciting");

   
})

server.listen(5678,() =>{
    console.log("Server is listening on port 5678");
});


