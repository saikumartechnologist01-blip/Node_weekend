const express = require('express');
const app = express();
app.use(express.json()); // middleware

var products =[
    {
        id:1,
        name:"Laptop",
        price:45000
    },
    {
        id:2,
        name:"Mobile",
        price:25000
    }
]

var users =[
    {
        id:1,
        name:"Sai"
    },
    {
        id:2,
        name:"Kumar"
    }
];

// GET Products -API

app.get("/products",(request,response) =>{
    response.send(products); 
})

// GET Product by id - API

app.get("/products/:id", (request,response) =>{
    console.log("inside get product by id");
    var productId = parseInt(request.params.id);
    var product = products.find(p => p.id === productId);
    if(product){
        response.send(product);
    } else {
        response.status(404).send("Product not found");
    }
});

// Update Product - API

app.put("/products/:id",(request,response) =>{
   
    var productId = parseInt(request.params.id);
    var updatedProduct = request.body;
    console.log("updated product:", updatedProduct);
    console.log("product id:", productId);
    var productIndex = products.findIndex(p => p.id === productId);  
    if(productIndex !== -1){
        products[productIndex] = updatedProduct;
        response.send("Product updated successfully");
    } else {
        response.status(404).send("Product not found");
    }  
})  

// Delete Product - API

app.delete("/products/:id",(request,response) =>{
   
    var productId = parseInt(request.params.id);
    var productIndex = products.findIndex(p => p.id === productId);
    if(productIndex !== -1){
        products.splice(productIndex, 1);
        response.send("Product deleted successfully");
    } else {
        response.status(404).send("Product not found");
    }
})

// GET Users -API

app.get("/users",(request,response) =>{
    response.send(users);
})

// POST Product - API
app.post("/product",(request,response) =>{
   var product =  request.body;
    products.push(product);
    response.send("product added successfully");
});

app.listen(8787,() =>{
    console.log("Server is running on port 8787");
})

// http://localhost:8787/products