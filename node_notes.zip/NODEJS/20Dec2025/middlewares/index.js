var express = require('express');
var app= express();


// Logger Middleware :  It prints the request time

var loggerMiddleware = (req,res,next) =>{
    var currentDate = new Date();
    console.log("Request Time : ", currentDate.toString());
    next();
}

// Authentication Middleware
var authMiddleware = (req,res,next) =>{

   var token = req.headers.token;

    if(token === "76767"){
        next();
    }
    else{
        res.send("Unauthorized Access! please send valid token");
    }

    }
    // app.use(loggerMiddleware);
    // app.use(authMiddleware);
   

app.get("/users",(req,res) =>{
    // Logic to validate the user - token

   throw new Error("Some error occurred while fetching users");
    res.send([
        {
            id:101,
            name:"Alice",
            age:28
        },
         {
            id:102,
            name:"John",
            age:29
        }
    ])
})

app.get("/products",(req,res) =>{
    // Logic to validate the user - token
    res.send([
        {
            id:201,
            name:"Laptop",
            price:1200 
        },
         {
            id:202, 
            name:"Smartphone",
            price:800
        }
    ])
});
var errorHandlingMiddleware = (err, req, res, next ) =>{
    console.error("Error Caught by Middleware : ", err.message);
    res.status(500).send("Something went wrong! Please try again later.");
}
app.use(errorHandlingMiddleware);

app.listen(3003, function(){  
    console.log("Server is running on port 3003");
});