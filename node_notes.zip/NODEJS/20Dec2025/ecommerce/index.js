var express=require("express");

var app = express(); 

app.use(express.json());

var sellerRoute = require("./routes/seller.route");

app.use("/seller",sellerRoute);

app.get("/health", (req,res) =>{
    res.send("The app is up and running");
})


app.listen(9001, () =>{
    console.log("server started!!");
})


// To create APIs for user management, 
// To create APIs for seller management.


