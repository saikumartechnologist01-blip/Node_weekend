var express = require('express');

var sellerRouter = express.Router();

sellerRouter.get("/all",(req,res) =>{
    res.send(
        [
            {
                id:101,
                name:"Seller One"
            },
             {
                id:102,
                name:"Seller Two"
            }
        ]
    );
})

sellerRouter.post("/add",(req,res) =>{
    console.log(req.body);
    var sellerData = req.body; 
    res.send(sellerData);
})

module.exports = sellerRouter 


