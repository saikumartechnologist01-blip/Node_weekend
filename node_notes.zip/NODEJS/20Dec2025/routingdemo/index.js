var express = require('express');
var app = express();
var productRoutes = require('./routes/product.route');
var port = 9000;

// http://localhost:9000/api/
app.use('/api', productRoutes);

app.get('/', function(req, res) {
    res.send('Welcome to the Home Page!');
});


app.listen(port, function() {
    console.log('Server is running on http://localhost:' + port);
});