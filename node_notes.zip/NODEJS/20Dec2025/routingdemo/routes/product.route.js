var router = require('express').Router();

var loggerMiddleware = (req,res,next) =>{
    var currentDate = new Date();
    console.log("Request Time : ", currentDate.toString());
    next();
}

router.use(loggerMiddleware);

router.get('/products', function(req, res) {
    res.send('List of Products');
});

router.get('/products/:id', function(req, res) {
    var productId = req.params.id;
    res.send('Details of Product ID: ' + productId);
});

router.post('/product ', function(req, res) {
    res.send('Create a new Product');
});

module.exports = router;