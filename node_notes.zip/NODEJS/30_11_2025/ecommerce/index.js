 var http = require("http");
 
 http.createServer((request, response) =>{
     response.writeHead(200, {'Content-Type': 'application/json' });
     response.end(JSON.stringify({
         product: "Laptop",
         price: 1200,
         currency: "USD"
     }));
 }).listen(9000, () =>{
    console.log("server started");
 });


 
