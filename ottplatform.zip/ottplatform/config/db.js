
const mongoose = require('mongoose'); 

const connectDB = async () => {

    console.log('Connecting to MongoDB...');

    try{
   await mongoose.connect('mongodb://localhost:27017/ottplatform');
    console.log('Connected to MongoDB');

    }
    catch(err){
        console.error('Error connecting to MongoDB', err);
    }
}
module.exports= connectDB;