
const express = require('express');
const app = express();
const port = 9000;

app.use(express.json()); // middleware
const userRouter = require('./routes/user.route');
app.use('/users', userRouter);
const connectDB = require('./config/db');
connectDB();

app.listen(port, () => {
  console.log(`OTT Platform service running at http://localhost:${port}`);
});


