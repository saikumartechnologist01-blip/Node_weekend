
const express = require('express');
const app = express();
const port = 9000;

const connectDB = require('./config/db');
connectDB();

app.listen(port, () => {
  console.log(`OTT Platform service running at http://localhost:${port}`);
});


