
const User = require('../models/User');


exports.registerUser = async(req,res) =>{

    try{
         await User.create(req.body);
        res.status(201).json({
            success:true,
            message:"User registered successfully"})
    }
    catch(err){
         res.status(500).json({
            error:err.message
         })

    }
}
