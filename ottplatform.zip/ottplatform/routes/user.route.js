const express = require('express');
const userRouter = express.Router();
const UserController = require('../controllers/user.controller');


userRouter.post('/register',UserController.registerUser);
module.exports = userRouter;