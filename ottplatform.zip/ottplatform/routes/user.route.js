const express = require('express');
const userRouter = express.Router();
const UserController = require('../controllers/user.controller');


userRouter.post('/register',UserController.registerUser);
userRouter.get('/',UserController.getUsers);
userRouter.post('/login',UserController.login);
module.exports = userRouter;